import React,{Component} from 'react'
import{BrowserRouter,Routes,Route} from 'react-router-dom'
import Button from 'react-bootstrap/Button';
import {Link} from 'react-router-dom'

import './Home.css'
class Home extends Component {
render() {
	
	return (
	
	
		<body>
		{/*<h1 className="text1">Welcome to Leave Management System</h1>
		<center><h1><Button size="lg"><Link to="/EmployeeLogin">EmployeeLogin</Link></Button></h1></center>&nbsp;&nbsp;<center><h1><Button size="lg"><Link to="/ManagerLogin">ManagerLogin</Link></Button></h1></center>*/}
		{/*<Button size="lg"><Link to="/EmployeeLogin">EmployeeLogin</Link></Button>&nbsp;&nbsp;&nbsp;<br></br>
		<Button size="lg"><Link to="/ManagerLogin">ManagerLogin</Link></Button>*/}
		<h1 className="text1">Welcome to Leave Management System</h1>
		<form className="text2">
			<br></br>
<br></br><br></br><br></br>		<Button  className="btn10"size="lg"><Link to="/EmployeeLogin">EmployeeLogin</Link></Button><br></br><br></br>
		<Button className="btn10"size="lg"><Link to="/ManagerLogin">ManagerLogin</Link></Button>
		</form>
		</body>
	
	
	
	)
}
}

export default Home;