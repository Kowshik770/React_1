import axios from 'axios';
import React, { Component } from 'react';
import './ManagerLogin.css'
import Inbox from './Inbox'
import './App.css'
import Button from 'react-bootstrap/esm/Button'

export default class ManagerLogin extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         email:'',
         password:'',
         
      }
      this.handlechange=this.handlechange.bind(this);
      this.ManagerLogin=this.ManagerLogin.bind(this);
    }
    handlechange(e){
        this.setState(e);
    }

ManagerLogin(e){
        console.log(this.state.empid);
        console.log(this.state.password);
        axios.get("http://localhost:22452/api/Manager/Login/"+this.state.email+ '/'+this.state.password).
        then(res=>res).then(
            result=>{
                console.log(result.data)
                let r=result.data;
                console.log(r)
                localStorage.setItem("manager_id",result.data.managerId);
                localStorage.setItem("managername",result.data.managerName);
                if(r!=null){
                    alert("welcome "+ result.data.managerName);
                    window.location="/ManagerInbox"
                    
                }else{
                    alert("invalid credentials");
                }
                //window.sessionStorage.setItem("empid",result.data.employeeid);
            }).catch(err=>{
                alert(err);

            });
    }


    
  render() {
    return (
      <>
      <body>
      <div className='review'>
    <h1 className="heading">Manager Login</h1>
    <div className='form-group' >
    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="Black" class="bi bi-person-circle" viewBox="0 0 16 16">
<path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
<path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
</svg>
    <label>&nbsp;&nbsp;Username</label>
    <input type='email' className='form-control' onChange={(e)=> this.handlechange({email:e.target.value})} placeholder='enter email' required /><br/>
    </div>
    <div className='form-group' >
    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="Black" class="bi bi-lock-fill" viewBox="0 0 16 16">
  <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/>
</svg>
    <label>&nbsp;&nbsp;Password</label>
    <input type='password' className='form-control' onChange={(e)=> this.handlechange({password:e.target.value})} placeholder='enter password' required />
    <br/></div>
    <center><button  onClick={this.ManagerLogin} >Login</button></center>
    &nbsp;&nbsp;<center><Button href="ManagerRegistration">Signup</Button></center>
    </div>
    </body>
    </>
    )
  }
}